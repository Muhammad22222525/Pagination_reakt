import React, { useState, useEffect } from "react";
import Header from "./components/header";

function App() {
  const [data, setData] = useState();
  let [page, setPage] = useState(1);  
  const [limit, setLimit] = useState(10);
  const totPages = 20

  useEffect(() => {
    fetch(
      `https://jsonplaceholder.typicode.com/todos?_page=${page}&_limit=${limit}`
    )
      .then((response) => response.json())
      .then((json) => setData(json));
  }, [page, limit]);

  return (
    <div>
      <Header 
        svg={<svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="4" cy="12" r="2" fill="#3B82F6"/>
                  <circle cx="12" cy="12" r="2" fill="#3B82F6"/>
                  <circle cx="20" cy="12" r="2" fill="#3B82F6"/>
              </svg>}
        pagin="Pagination" 
        page="Page:" 
        pSpan={page} 
        setlimit={setLimit}
      />
      {data?.map((item) => (
        <div key={item.id} className="border border-green-500 p-2 m-2 rounded-md">
          <p>{item.title}</p>
        </div>
      ))}
      <div className="flex gap-2">
        <button onClick={() => setPage((prev) => prev > 1 ? prev - 1 : prev)} className="px-4 py-2 bg-gray-300 rounded">prev</button>
        {Array.from({length: totPages}).map((i,index) => (
          <button
          type="button"
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 mr-[10px] focus:bg-blue-600 `${index + 1 === page ? bg-blue-700}`"
          onClick={setPage((prev) => index + 1)}
        >
          {index + 1}
        </button>
        

          
        ))}
        <button onClick={() => setPage((prev) => prev + 1)} className="px-4 py-2 bg-gray-300 rounded">next</button>
      </div>
    </div>
  );
}

export default App;
